#include "Acorn.hpp"

const int Acorn::PHOTO_ENERGY = 5;
const int Acorn::GROW_ENERGY = 20;
const int Acorn::MOVES = 4;

// TODO