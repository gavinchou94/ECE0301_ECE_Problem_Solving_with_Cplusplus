#include "Squirrel.hpp"

const int Squirrel::MOVES = 2;
const int Squirrel::MOVE_ENERGY = 5;

// TODO