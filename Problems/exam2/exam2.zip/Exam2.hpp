#ifndef EXAM2_HPP
#define EXAM2_HPP

#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>
#include <stdexcept>
#include <algorithm>
#include <vector>

// declare your class here
class SampleClass
{
private:
  // private data members can be declared here
public:
  void displayMessage() const;
  // ...
};
#endif