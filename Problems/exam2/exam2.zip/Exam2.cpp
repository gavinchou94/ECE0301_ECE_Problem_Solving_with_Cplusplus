#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cmath>
#include <stdexcept>
#include <algorithm>
#include <vector>

#include "Exam2.hpp"

void SampleClass::displayMessage() const
{
  std::cout << "Object-oriented programming rocks!" << std::endl;
}
