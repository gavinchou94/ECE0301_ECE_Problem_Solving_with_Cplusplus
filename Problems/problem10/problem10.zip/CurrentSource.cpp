#include "CurrentSource.hpp"

double CurrentSource::get_current() const
{
    // TODO
    return 0.0;
}