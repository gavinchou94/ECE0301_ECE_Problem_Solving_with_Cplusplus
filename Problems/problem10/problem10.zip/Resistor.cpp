#include "Resistor.hpp"

void Resistor::set_value(double r)
{
    // TODO
}

double Resistor::get_current() const
{
    // TODO
    return 0.0;
}
