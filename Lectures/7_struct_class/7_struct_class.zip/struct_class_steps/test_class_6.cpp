// This is test_class_6.cpp
// Changes compared to test_class_5.cpp:
// - test overloaded operators
// - test member and non-member function
#define CATCH_CONFIG_MAIN

#include "Employee_6.hpp"
#include "catch.hpp"

TEST_CASE("Class init", "[class]")
{
  Date d(2026, 10, 21);          // change to declare an Date object called d
  Employee e1("Panther", 20, d); // declare an object called e1
  // e1 is constructed using () and args

  REQUIRE(e1.get_name() == "Panther");          // e1.name is not possible since it's outside class now
  REQUIRE(e1.get_hourly_rate() == 20);          // getter functions solve such problems
  REQUIRE(e1.get_starting_date().get_year() == 2026); // struct cannot be directly compared via ==
  REQUIRE(e1.get_starting_date().get_month() == 10);
  REQUIRE(e1.get_starting_date().get_day() == 21);
}

TEST_CASE("Class init without info", "[class]")
{
  Employee e2; // declare an object called e2 without passing any information

  // test the default attribute of the object e2
  REQUIRE(e2.get_name() == "");
  REQUIRE(e2.get_hourly_rate() == 0);
  REQUIRE(e2.get_starting_date().get_year() == 1900);
  REQUIRE(e2.get_starting_date().get_month() == 1);
  REQUIRE(e2.get_starting_date().get_day() == 1);

  // use setter functions to modify object attributes
  REQUIRE(e2.set_name("Tim"));
  REQUIRE(e2.set_hourly_rate(15));
  Date d(2026, 5, 1);
  REQUIRE(e2.set_starting_date(d));

  // test the success of setter functions
  REQUIRE(e2.get_name() == "Tim");
  REQUIRE(e2.get_hourly_rate() == 15);
  REQUIRE(e2.get_starting_date().get_year() == 2026);
  REQUIRE(e2.get_starting_date().get_month() == 5);
  REQUIRE(e2.get_starting_date().get_day() == 1);

  // test other public functions
  REQUIRE(e2.get_weekly_rate() == 15 * 70);
  REQUIRE(e2.get_yearly_rate() == 15 * 70 * 52);
}

TEST_CASE("Class set date", "[class]")
{
  Date start(2026, 10, 22);
  REQUIRE(start.get_year() == 2026);
  REQUIRE(start.get_month() == 10);
  REQUIRE(start.get_day() == 22);
  start.set_year(1985);
  start.set_month(1);
  start.set_day(1);
  REQUIRE(start.get_year() == 1985);
  REQUIRE(start.get_month() == 1);
  REQUIRE(start.get_day() == 1);
}

TEST_CASE("Class set year validation", "[class]")
{
  Date start(2026, 10, 22);
  REQUIRE_THROWS_AS(start.set_year(1700), std::invalid_argument);
  REQUIRE_NOTHROW(start.set_year(1901));

  REQUIRE_THROWS_AS(Date(1500, 1, 1), std::invalid_argument);
  REQUIRE_NOTHROW(Date(2020, 1, 1));
}

TEST_CASE("Class test operator ==", "[class]")
{
  Date start_day(1985, 1, 1);
  Date start_day2(1985, 1, 1);
  REQUIRE(start_day.operator==(start_day2));
  REQUIRE(start_day == start_day2); // both statements are good
}

TEST_CASE("Class test non-member operator <", "[class]")
{
  Date start(1985, 10, 10);
  Date end1(1990, 3, 3);
  Date end2(1985, 11, 1);
  Date end3(1985, 10, 31);
  REQUIRE(start < end1);
  // REQUIRE(start.operator<(end1)); // this statement would run into error
  // because operator< is non-member function, cannot be called via member-function way
  REQUIRE(start < end2);
  REQUIRE(start < end3);
  // REQUIRE(end1 > end2);
}